#!/usr/bin/env bash

#pull dockers

docker pull jenkins
docker pull sonarqube
docker pull sonatype/nexus
docker pull tomcat

# launch dockers
docker run -d -p 8080:8080 --name jenkinsdemo jenkins
docker run -d -p 9000:9000 --name sqdemo sonarqube
docker run -d -p 8082:8081 --name nexusdemo sonatype/nexus
docker run -d -p 8083:8080 --name tomcatdemo tomcat

echo "containers running"

docker ps

# config.vm.network "private_network", ip: "192.168.33.10"
#get plugins in jenkins

sudo mkdir ~/JenkinsPluginsDemo
cd ~/JenkinsPluginsDemo
echo "now inside JenkinsPluginsTest"

echo "running plugin install"
#copy files into jenkins container
docker cp /Shared_Folder/iplugins jenkinsdemo:/iplugins
docker cp /Shared_Folder/batch-install-jenkins-plugins.sh jenkinsdemo:/batch-install-jenkins-plugins.sh

#execute plugins command inside jenkins container
docker exec jenkinsdemo /batch-install-jenkins-plugins.sh --plugins iplugins --plugindir /var/jenkins_home/plugins

echo "jenkins setup complete"
echo "access the server via http://iphere:8080	complete setup and safeRestart jenkins"




sudo docker run -t -i -p 8080:8080 -v /etc/localtime:/etc/localtime:ro -P --name jenkins2 stephenreed/jenkins-java8-maven-git